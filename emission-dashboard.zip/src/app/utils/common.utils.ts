export function formatNumberWithCommas(num: number): string {
  return num.toLocaleString('en-US');
}
