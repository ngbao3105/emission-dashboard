export enum EmissionCategoryEnum {
  SCOPE_1 = 'SCOPE_1',
  SCOPE_2 = 'SCOPE_2',
  SCOPE_3 = 'SCOPE_3'
}
